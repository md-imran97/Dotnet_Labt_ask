﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DbTest_Lab1.Models.Entity;
using DbTest_Lab1.Models;
using System.Web.Script.Serialization;

namespace DbTest_Lab1.Controllers
{
    public class ProductController : Controller
    {

        // GET: Product
        //Session["items"]="";
        //int track = 0;
        public ActionResult Index()
        {
            
            return View();
        }
      
        [HttpGet]
        public ActionResult create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult create(Product p)
        {
            if (Session["items"] == null)
            {
                Session["items"] = null;
            }
            string error = "";
            if(ModelState.IsValid)
            {
                Database db = new Database();
                db.product.Add(p);
                return RedirectToAction("show");
            }
            error = "all field required";
            ViewBag.error = error;
            return View();
        }

        public ActionResult show()
        {
            //Session["items"] = "yo man";
            Database db = new Database();
            var pList = db.product.GetAll();
            ViewBag.cartProducts = 0;
            if (Session["items"] != null)
            {
                string json = Session["items"].ToString();
                var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                ViewBag.cartProducts = d.Count;
            }
            
            return View(pList);
        }
        [HttpGet]
        public ActionResult update()
        {
            if (Request["id"] == null)
            {
                return RedirectToAction("show");
            }
            int id = Int32.Parse(Request["id"]);
            Database db = new Database();
            Product p = db.product.getOne(id);
            return View(p);
        }
        [HttpPost]
        public ActionResult update(Product p)
        {
            string error = "";
            Database db = new Database();
            //return RedirectToAction("show");
            if (ModelState.IsValid)
            {
                //Database db = new Database();
                db.product.update(p);
                return RedirectToAction("show");
            }
             error = "all field required";
            ViewBag.error = error;
            db = new Database();
            Product p1 = db.product.getOne(p.id);
            return View(p1);
        }

        public ActionResult delete()
        {
            if (Request["id"] == null)
            {
                return RedirectToAction("show");
            }
            int id = Int32.Parse(Request["id"]);
            Database db = new Database();
            db.product.delete(id);


            return RedirectToAction("show");
        }
        public ActionResult cart()
        {
            Database db = new Database();
            List<Product> pro = new List<Product>();
            if (Request["id"]!=null)
            {
                
                int id = Int32.Parse(Request["id"]);
                Product p = db.product.getOne(id);
                pro.Add(p);
                if (Session["items"] ==null)
                {
                    string json = new JavaScriptSerializer().Serialize(pro);
                    Session["items"] = json;
                    //track++;
                    //ViewBag.cartProducts =1;
                }
                else
                {
                    string json = Session["items"].ToString();
                    var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                    d.Add(p);
                    pro = d;
                    string upJson = new JavaScriptSerializer().Serialize(pro);
                    Session["items"] = upJson;
                    //track++;
                    //ViewBag.cartProducts = d.Count;
                }

                return RedirectToAction("show");
            }
            if(Request["id"] == null && Session["items"] != null)
            {
                string json = Session["items"].ToString();
                var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                pro = d;
                ViewBag.cartProducts = d.Count;
                return View(pro);
            }
            return RedirectToAction("show");

        }
        public ActionResult checkout()
        {
            if(Session["items"]==null)
            {
                return RedirectToAction("show");
            }
            Database db = new Database();
            string json = Session["items"].ToString();
            var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
            db.cart.addCart(111);
            int buyId = db.cart.rowCount();
            db.item.addItems(d, buyId);
            Session["items"] = null;
            return View();
        }
        public ActionResult refresh()
        {
            return View();
        }
    }
}