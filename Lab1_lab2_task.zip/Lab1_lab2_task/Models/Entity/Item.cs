﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DbTest_Lab1.Models.Entity
{
    public class Item
    {
        public int id { get; set; }
        public int itemId { get; set; }
        public int buyId { get; set; }
    }
}