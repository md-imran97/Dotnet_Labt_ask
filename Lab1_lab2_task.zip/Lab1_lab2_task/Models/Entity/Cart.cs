﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DbTest_Lab1.Models.Entity
{
    public class Cart
    {
        public int buyId { get; set; }
        public int userId { get; set; }
    }
}