﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using DbTest_Lab1.Models.Entity;

namespace DbTest_Lab1.Models.Table
{
    public class Items
    {
        SqlConnection conn;
        public Items(SqlConnection conn)
        {
            this.conn = conn;
        }

        public void addItems(List<Product> items, int buyId)
        {
            foreach(var item in items)
            {
                string query = String.Format("Insert into items values ('{0}','{1}')", item.id, buyId);
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                int r = cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
    }
}