﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DbTest_Lab1.Models.Table
{
    public class Carts
    {
        SqlConnection conn;
        public Carts(SqlConnection conn)
        {
            this.conn = conn;
        }

        public void addCart(int userId)
        {
            string query = String.Format("Insert into carts values ('{0}')", userId);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            int r = cmd.ExecuteNonQuery();
            conn.Close();
        }
        public int rowCount()
        {
            string query = "select * from carts";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count++;
            }
            conn.Close();
            return count;
        }
    }
}