﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DbTest_Lab1.Models.Entity;
using DbTest_Lab1.Models;
using System.Web.Script.Serialization;

namespace DbTest_Lab1.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(User u)
        {
            if (ModelState.IsValid)
            {
                User user = null;
                Database db = new Database();
                user = db.user.verify(u.phone, u.password);
                if (user != null)
                {
                    if (user.userType == 1)
                    {
                        Session["phone"] = user.phone;
                        Session["type"] = user.userType;
                        return RedirectToAction("admin");
                    }
                    else if(user.userType==2)
                    {
                        Session["phone"] = user.phone;
                        Session["type"] = user.userType;
                        return RedirectToAction("customer");
                    }
                    
                }
                else
                {
                    ViewBag.error = "Phone or password is incorrect";
                    return View();
                }
            }

          
            return View();
        }
        public ActionResult Customer()
        {
            if (Session["type"] == null) { return RedirectToAction("Login"); }
            if ((int)Session["type"] == 1) { return RedirectToAction("Admin"); }
            Database db = new Database();
            var pList = db.product.GetAll();
            ViewBag.cartProducts = 0;
            if (Session["items"] != null)
            {
                string json = Session["items"].ToString();
                var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                ViewBag.cartProducts = d.Count;
            }

            return View(pList);
        }
        public ActionResult Admin()
        {
            return View();
        }

        public ActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Signup(User u)
        {
            if(ModelState.IsValid)
            {
                User user = null;
                Database db = new Database();
                user = db.user.check(u.phone);
                if(user == null)
                {
                    db.user.Add(u);
                }
                else
                {
                    ViewBag.error = "user phone nuber already exist";
                }
            }
            return View();
        }
        public ActionResult cart()
        {
            if (Session["type"]==null) { return RedirectToAction("Login"); }
            if((int)Session["type"] == 1) { return RedirectToAction("Admin"); }
            Database db = new Database();
            List<Product> pro = new List<Product>();
            if (Request["id"] != null)
            {

                int id = Int32.Parse(Request["id"]);
                Product p = db.product.getOne(id);
                pro.Add(p);
                if (Session["items"] == null)
                {
                    string json = new JavaScriptSerializer().Serialize(pro);
                    Session["items"] = json;
                    //track++;
                    //ViewBag.cartProducts =1;
                }
                else
                {
                    string json = Session["items"].ToString();
                    var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                    d.Add(p);
                    pro = d;
                    string upJson = new JavaScriptSerializer().Serialize(pro);
                    Session["items"] = upJson;
                    //track++;
                    //ViewBag.cartProducts = d.Count;
                }

                return RedirectToAction("customer");
            }
            if (Request["id"] == null && Session["items"] != null)
            {
                string json = Session["items"].ToString();
                var d = new JavaScriptSerializer().Deserialize<List<Product>>(json);
                pro = d;
                ViewBag.cartProducts = d.Count;
                return View(pro);
            }
            return RedirectToAction("customer");

        }
    }
}