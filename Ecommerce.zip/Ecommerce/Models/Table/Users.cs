﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using DbTest_Lab1.Models.Entity;


namespace DbTest_Lab1.Models.Table
{
    public class Users
    {
        SqlConnection conn;
        public Users(SqlConnection conn)
        {
            this.conn = conn;
        }

        public User verify(string phone, string password)
        {
            string query = "select * from users where phone='" + phone + "' and password='" + password + "'";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            User user=null;
            while (reader.Read())
            {
                user = new User();
                user.userName = reader.GetString(reader.GetOrdinal("userName"));
                user.phone = reader.GetString(reader.GetOrdinal("phone"));
                user.password = reader.GetString(reader.GetOrdinal("password"));
                user.userType = reader.GetInt32(reader.GetOrdinal("userType"));
            }     
            conn.Close();
            return user;
        }

        public void Add(User u)
        {
            string query = String.Format("Insert into users values ('{0}','{1}','{2}',{3})", u.phone, u.userName, u.password, u.userType);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            int r = cmd.ExecuteNonQuery();
            conn.Close();
        }

        public User check(string phone)
        {
            string query = "select * from users where phone='" + phone + "'";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            User user = null;
            while (reader.Read())
            {
                user = new User();
            }
            conn.Close();
            return user;
        }
    }
}