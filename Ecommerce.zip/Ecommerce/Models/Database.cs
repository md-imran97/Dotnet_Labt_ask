﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using DbTest_Lab1.Models.Table;

namespace DbTest_Lab1.Models
{
    public class Database
    {
        public Products product { get; set; }
        public Items item { get; set; }
        public Carts cart { get; set; }
        public Users user { get; set; }

        public Database()
        {
            string connString = @"Server=DESKTOP-JMLJ4K3\SQLEXPRESS;Database=lab1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            product = new Products(conn);
            item = new Items(conn);
            cart = new Carts(conn);
            user = new Users(conn);
            
        }
    }
}