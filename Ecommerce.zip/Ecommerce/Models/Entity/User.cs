﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DbTest_Lab1.Models.Entity
{
    public class User
    {
        [Required(ErrorMessage = "Please Provide uesr name")]
        public string userName { get; set; }

        [Required(ErrorMessage = "Please Provide password")]
        public string password { get; set; }

        [Required(ErrorMessage = "Please Provide user type")]
        public int userType { get; set; }

        [Required(ErrorMessage = "Please Provide phone")]
        public string phone { get; set; }
    }
}