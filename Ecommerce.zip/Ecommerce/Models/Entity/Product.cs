﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace DbTest_Lab1.Models.Entity
{
    public class Product
    {
        public int id { get; set; }

        [Required(ErrorMessage = "Please Provide name")]
        [MinLength(2, ErrorMessage = "Name must be > 2 character")]
        [MaxLength(10, ErrorMessage = "Name should not exceed 10 character")]
        public string name { get; set; }

        [Required(ErrorMessage = "Please Provide price")]
        public int price { get; set; }

        [Required(ErrorMessage = "Please Provide quantity")]
        public int quantity { get; set; }

        [Required(ErrorMessage = "Please Provide description")]
        public string description { get; set; }
    }
}